﻿# HeidiSQL Dump 
#
# --------------------------------------------------------
# Host:                         127.0.0.1
# Database:                     db_mainproject
# Server version:               5.0.51b-community-nt
# Server OS:                    Win32
# Target compatibility:         ANSI SQL
# HeidiSQL version:             4.0
# Date/time:                    2022-05-17 10:12:06
# --------------------------------------------------------

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI,NO_BACKSLASH_ESCAPES';*/
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;*/


#
# Database structure for database 'db_mainproject'
#

CREATE DATABASE /*!32312 IF NOT EXISTS*/ "db_mainproject" /*!40100 DEFAULT CHARACTER SET latin1 */;

USE "db_mainproject";


#
# Table structure for table 'tbl_abworks'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_abworks" (
  "abworks_id" int(10) unsigned NOT NULL auto_increment,
  "ab_id" int(10) unsigned NOT NULL,
  "works_id" int(10) unsigned NOT NULL,
  "user_count" int(10) unsigned NOT NULL,
  "adworks_amount" bigint(20) unsigned NOT NULL,
  PRIMARY KEY  ("abworks_id")
);



#
# Dumping data for table 'tbl_abworks'
#

# No data found.



#
# Table structure for table 'tbl_admin'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_admin" (
  "admin_id" int(10) unsigned NOT NULL auto_increment,
  "admin_username" varchar(50) NOT NULL,
  "admin_password" varchar(50) NOT NULL,
  PRIMARY KEY  ("admin_id"),
  UNIQUE KEY "admin_id" ("admin_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'tbl_admin'
#

LOCK TABLES "tbl_admin" WRITE;
/*!40000 ALTER TABLE "tbl_admin" DISABLE KEYS;*/
REPLACE INTO "tbl_admin" ("admin_id", "admin_username", "admin_password") VALUES
	('1','admin','admin');
/*!40000 ALTER TABLE "tbl_admin" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_advancedbooking'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_advancedbooking" (
  "ab_id" int(10) unsigned NOT NULL auto_increment,
  "shop_id" int(10) unsigned NOT NULL,
  "ab_date" date NOT NULL,
  "ab_totalamount" int(10) unsigned default NULL,
  "ab_progressstatus" int(10) unsigned NOT NULL default '0',
  "user_id" int(10) unsigned NOT NULL,
  PRIMARY KEY  ("ab_id")
) AUTO_INCREMENT=28;



#
# Dumping data for table 'tbl_advancedbooking'
#

LOCK TABLES "tbl_advancedbooking" WRITE;
/*!40000 ALTER TABLE "tbl_advancedbooking" DISABLE KEYS;*/
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('1','6','2022-03-18',NULL,'1','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('2','6','2022-04-02',NULL,'2','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('3','6','2022-04-01',NULL,'2','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('4','6','2022-03-02',NULL,'1','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('5','6','2022-04-01',NULL,'1','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('6','6','2022-02-28',NULL,'2','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('7','6','2022-03-02',NULL,'2','2');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('8','6','2022-03-01',NULL,'1','2');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('9','6','2022-03-02',NULL,'2','2');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('10','6','2022-03-03',NULL,'0','2');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('11','6','2022-03-05',NULL,'2','2');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('12','6','2022-03-02',NULL,'1','2');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('13','4','2022-03-20',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('14','4','2022-03-13',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('15','5','2022-03-19',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('16','6','2022-04-14',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('17','6','2022-04-05',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('18','6','2022-03-31',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('19','6','2022-03-31',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('20','6','2022-03-31',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('21','6','2022-04-22',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('22','6','2022-04-22',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('23','6','2022-04-30',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('24','6','2022-03-31',NULL,'1','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('25','4','2022-05-10',NULL,'0','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('26','3','2022-05-20',NULL,'1','1');
REPLACE INTO "tbl_advancedbooking" ("ab_id", "shop_id", "ab_date", "ab_totalamount", "ab_progressstatus", "user_id") VALUES
	('27','16','2022-05-20',NULL,'1','6');
/*!40000 ALTER TABLE "tbl_advancedbooking" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_complaints'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_complaints" (
  "complaint_id" int(10) unsigned NOT NULL auto_increment,
  "shop_id" int(10) unsigned NOT NULL,
  "user_id" int(10) unsigned NOT NULL,
  "complaint_reply" varchar(50) default NULL,
  "complaint_description" varchar(50) default NULL,
  "complaint_senddate" date NOT NULL,
  "complaint_vstatus" int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  ("complaint_id")
) AUTO_INCREMENT=6;



#
# Dumping data for table 'tbl_complaints'
#

LOCK TABLES "tbl_complaints" WRITE;
/*!40000 ALTER TABLE "tbl_complaints" DISABLE KEYS;*/
REPLACE INTO "tbl_complaints" ("complaint_id", "shop_id", "user_id", "complaint_reply", "complaint_description", "complaint_senddate", "complaint_vstatus") VALUES
	('2','6','1','zxcvbnm','vvjhkhjkhkhk','2022-03-18','1');
REPLACE INTO "tbl_complaints" ("complaint_id", "shop_id", "user_id", "complaint_reply", "complaint_description", "complaint_senddate", "complaint_vstatus") VALUES
	('3','7','1',NULL,'qwertyuidfg','2022-03-18','0');
REPLACE INTO "tbl_complaints" ("complaint_id", "shop_id", "user_id", "complaint_reply", "complaint_description", "complaint_senddate", "complaint_vstatus") VALUES
	('4','7','1',NULL,'bad service','2022-05-08','0');
REPLACE INTO "tbl_complaints" ("complaint_id", "shop_id", "user_id", "complaint_reply", "complaint_description", "complaint_senddate", "complaint_vstatus") VALUES
	('5','11','7','thanks for your comment','bad service','2022-05-12','1');
/*!40000 ALTER TABLE "tbl_complaints" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_complainttype'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_complainttype" (
  "complainttype_id" int(10) unsigned NOT NULL auto_increment,
  "complainttype_name" varchar(50) NOT NULL,
  PRIMARY KEY  ("complainttype_id")
);



#
# Dumping data for table 'tbl_complainttype'
#

# No data found.



#
# Table structure for table 'tbl_district'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_district" (
  "district_id" int(10) unsigned NOT NULL auto_increment,
  "district_name" varchar(50) NOT NULL,
  PRIMARY KEY  ("district_id")
) AUTO_INCREMENT=14;



#
# Dumping data for table 'tbl_district'
#

LOCK TABLES "tbl_district" WRITE;
/*!40000 ALTER TABLE "tbl_district" DISABLE KEYS;*/
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('9','kottyam');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('10','Idukka');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('11','ernakula');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('12','idukki');
REPLACE INTO "tbl_district" ("district_id", "district_name") VALUES
	('13','Ernakualm');
/*!40000 ALTER TABLE "tbl_district" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_employees'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_employees" (
  "employye_id" int(10) unsigned NOT NULL auto_increment,
  "employee_name" varchar(50) NOT NULL,
  "employee_email" varchar(50) NOT NULL,
  "employee_gender" varchar(50) NOT NULL,
  "employee_photo" varchar(50) NOT NULL,
  "employee_experience" varchar(50) NOT NULL,
  "employee_phone" bigint(20) unsigned NOT NULL,
  "employee_password" varchar(50) NOT NULL,
  "employee_isactive" int(10) unsigned NOT NULL default '0',
  "shop_id" int(10) unsigned NOT NULL,
  "employee_doj" varchar(50) NOT NULL,
  PRIMARY KEY  ("employye_id")
) AUTO_INCREMENT=17;



#
# Dumping data for table 'tbl_employees'
#

LOCK TABLES "tbl_employees" WRITE;
/*!40000 ALTER TABLE "tbl_employees" DISABLE KEYS;*/
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('8','isaac maria','isac@mail.com','male','emplyees_1718.png','--select--','7894561237','Isac@123','1','7','2022-02-26');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('9','saanvi','saanvi@gmail.com','female','emplyees_1966.png','3','9745308567','saanvi123','1','14','2022-05-12');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('10','amelia','amelia@gmail.com','female','emplyees_1362.png','4','9745308566','amelia123','1','14','2022-05-12');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('11','ava','ava@gmail.com','female','emplyees_2089.png','4','9745307855','ava123','1','13','2022-05-12');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('12','emma','emma@gmail.com','female','emplyees_1079.png','4','9745302998','ema123','1','13','2022-05-12');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('13','aria','aria@gmail.com','female','emplyees_1030.png','1','9745307859','aria123','1','12','2022-05-12');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('14','alice','alice@123','female','emplyees_1911.png','5+','9745302566','alice123','1','12','2022-05-12');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('15','ruby','ruby@123','female','emplyees_1972.png','5+','9745308565','ruby123','1','11','2022-05-12');
REPLACE INTO "tbl_employees" ("employye_id", "employee_name", "employee_email", "employee_gender", "employee_photo", "employee_experience", "employee_phone", "employee_password", "employee_isactive", "shop_id", "employee_doj") VALUES
	('16','emily','emily@123','female','emplyees_1292.png','3','9745308569','emily123','1','11','2022-05-12');
/*!40000 ALTER TABLE "tbl_employees" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_employeeworks'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_employeeworks" (
  "empwork_id" int(10) unsigned NOT NULL auto_increment,
  "employye_id" int(10) unsigned NOT NULL,
  "works_id" int(10) unsigned NOT NULL,
  PRIMARY KEY  ("empwork_id")
);



#
# Dumping data for table 'tbl_employeeworks'
#

# No data found.



#
# Table structure for table 'tbl_place'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_place" (
  "place_id" int(10) unsigned NOT NULL auto_increment,
  "place_name" varchar(50) NOT NULL,
  "place_pincode" varchar(50) NOT NULL,
  "district_id" int(10) unsigned NOT NULL,
  PRIMARY KEY  ("place_id")
) AUTO_INCREMENT=11;



#
# Dumping data for table 'tbl_place'
#

LOCK TABLES "tbl_place" WRITE;
/*!40000 ALTER TABLE "tbl_place" DISABLE KEYS;*/
REPLACE INTO "tbl_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('2','muvattupuzha','686668','3');
REPLACE INTO "tbl_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('3','muvattupuzha','686668','3');
REPLACE INTO "tbl_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('4','muvattupuzha','686668','6');
REPLACE INTO "tbl_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('7','muvattupuzha','686668','11');
REPLACE INTO "tbl_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('8','thodupuzha','658865','10');
REPLACE INTO "tbl_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('9','kottayam','686664','9');
REPLACE INTO "tbl_place" ("place_id", "place_name", "place_pincode", "district_id") VALUES
	('10','ernakulam','686664','11');
/*!40000 ALTER TABLE "tbl_place" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_shop'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_shop" (
  "shop_id" int(10) unsigned NOT NULL auto_increment,
  "shopowner_id" int(10) unsigned NOT NULL,
  "shop_name" varchar(50) NOT NULL,
  "shop_contact" bigint(20) unsigned NOT NULL,
  "shop_email" varchar(50) NOT NULL,
  "place_id" int(10) unsigned NOT NULL,
  "shop_address" varchar(50) NOT NULL,
  "shop_logo" varchar(50) NOT NULL,
  "shop_licno" varchar(50) NOT NULL,
  "shop_proof" varchar(50) NOT NULL,
  "shop_doj" date NOT NULL,
  "shop_vstatus" int(10) unsigned default '0',
  "shop_username" varchar(50) NOT NULL,
  "shop_password" varchar(50) NOT NULL,
  PRIMARY KEY  ("shop_id")
) AUTO_INCREMENT=15;



#
# Dumping data for table 'tbl_shop'
#

LOCK TABLES "tbl_shop" WRITE;
/*!40000 ALTER TABLE "tbl_shop" DISABLE KEYS;*/
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('6','3','riya t','1111111112','a@gmail.com','7','mklopiu','logo_1278.png','1234','Proof_1113.png','2022-01-28','2','sho1234','1234');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('7','3','Helna','9898989898','helna@gmail.com','8','ejfwjdfwldwf','shoplogo_1433.png','326965656565','Proof_1057.png','2022-02-19','2','helna','helna@123');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('8','3','aashirvad cineplex','7894561237','abc@gmail.com','7','Nelcos, Jn., Pala Road, Thodupuzha, Kerala','shoplogo_1739.png','326965656565','Proof_1722.png','2022-02-25','2','anelna','258');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('9','3','SABITHA','7894561237','aleena@gmail.com','7','Nelcos, Jn., Pala Road, Thodupuzha, Kerala','shoplogo_1860.png','326965656565','Proof_1785.png','2022-02-25','2','anelna','357');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('10','4','anjana','9207813125','sarathkb15@gmail.com','8','muvattupuzha','shoplogo_1977.png','2513187029','Proof_1958.png','2022-04-12','2','anjana123','anjana123');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('11','4','enara make over studio','9745302996','enara@gmail.com','7','vallamattom estate
near po jn
muvattupuzha','shoplogo_1854.png','2513187029','Proof_2024.png','2022-05-12','1','enara123','enara');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('12','4','achus bridal villa','9745308563','achus@gmail.com','7','arakuzha road
near po jn
muvattupuzha','shoplogo_1907.png','2513187063','Proof_2102.png','2022-05-12','1','achus123','achus123');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('13','4','mist womens beauty studio','9745307852','achus@gmail.com','7','arakuzha road
near po jn
muvattupuzha','shoplogo_1192.png','2513187678','Proof_1518.png','2022-05-12','1','mist123','mist123');
REPLACE INTO "tbl_shop" ("shop_id", "shopowner_id", "shop_name", "shop_contact", "shop_email", "place_id", "shop_address", "shop_logo", "shop_licno", "shop_proof", "shop_doj", "shop_vstatus", "shop_username", "shop_password") VALUES
	('14','4','fai & lovely beauty care &bridal studio','9745302569','fair@gmail.com','7','arakuzha road
near po jn
muvattupuzha','shoplogo_1502.png','2513187612','Proof_1886.png','2022-05-12','1','fair123','fair123');
/*!40000 ALTER TABLE "tbl_shop" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_shopowner'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_shopowner" (
  "shopowner_id" int(10) unsigned NOT NULL auto_increment,
  "shopowner_name" varchar(50) NOT NULL,
  "shopowner_contact" bigint(20) unsigned NOT NULL,
  "shopowner_email" varchar(50) NOT NULL,
  "shopowner_aadharproof" varchar(50) NOT NULL,
  "shopowner_gender" varchar(50) NOT NULL,
  "shopowner_photo" varchar(50) NOT NULL,
  "district_id" int(10) unsigned NOT NULL,
  "shopowner_address" varchar(50) NOT NULL,
  "shopowner_password" varchar(50) NOT NULL,
  "shopowner_vstatus" int(10) unsigned default '0',
  PRIMARY KEY  ("shopowner_id")
) AUTO_INCREMENT=6;



#
# Dumping data for table 'tbl_shopowner'
#

LOCK TABLES "tbl_shopowner" WRITE;
/*!40000 ALTER TABLE "tbl_shopowner" DISABLE KEYS;*/
REPLACE INTO "tbl_shopowner" ("shopowner_id", "shopowner_name", "shopowner_contact", "shopowner_email", "shopowner_aadharproof", "shopowner_gender", "shopowner_photo", "district_id", "shopowner_address", "shopowner_password", "shopowner_vstatus") VALUES
	('3','Anu Jose','9876543256','a@gmail','6895674123','female','owner_1962.png','11','abc','21','2');
REPLACE INTO "tbl_shopowner" ("shopowner_id", "shopowner_name", "shopowner_contact", "shopowner_email", "shopowner_aadharproof", "shopowner_gender", "shopowner_photo", "district_id", "shopowner_address", "shopowner_password", "shopowner_vstatus") VALUES
	('4','alen mathew','7894561237','abc@gmail.com','123456789032','male','logo_1500.png','8','ERNAKULAM','123','1');
REPLACE INTO "tbl_shopowner" ("shopowner_id", "shopowner_name", "shopowner_contact", "shopowner_email", "shopowner_aadharproof", "shopowner_gender", "shopowner_photo", "district_id", "shopowner_address", "shopowner_password", "shopowner_vstatus") VALUES
	('5','aleena','9898989898','aleena@gmail.com','9587623147895','female','owner_1076.png','11','Nelcos, Jn., Pala Road, Thodupuzha, Kerala','456','2');
/*!40000 ALTER TABLE "tbl_shopowner" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_user'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_user" (
  "user_id" int(10) unsigned NOT NULL auto_increment,
  "user_name" varchar(50) NOT NULL,
  "user_contact" bigint(20) unsigned NOT NULL,
  "user_email" varchar(50) NOT NULL,
  "place_id" int(10) unsigned NOT NULL,
  "user_address" varchar(50) NOT NULL,
  "user_photo" varchar(50) NOT NULL,
  "user_username" varchar(50) NOT NULL,
  "user_password" varchar(50) NOT NULL,
  PRIMARY KEY  ("user_id")
) AUTO_INCREMENT=8;



#
# Dumping data for table 'tbl_user'
#

LOCK TABLES "tbl_user" WRITE;
/*!40000 ALTER TABLE "tbl_user" DISABLE KEYS;*/
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_contact", "user_email", "place_id", "user_address", "user_photo", "user_username", "user_password") VALUES
	('1','riya t','9876543256','a@gmail.com','7','qqq','logo_1786.png','anu123','riya');
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_contact", "user_email", "place_id", "user_address", "user_photo", "user_username", "user_password") VALUES
	('2','Adarsh','9565636565','adarsh@gmail.com','8','wbedj
whbdkw','User_1432.png','adarsh','adarsh');
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_contact", "user_email", "place_id", "user_address", "user_photo", "user_username", "user_password") VALUES
	('3','Adarsh','7894561237','adarsh@gmail.com','7','Nelcos, Jn., Pala Road, Thodupuzha, Kerala','User_1408.png','adarsh','adarsh');
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_contact", "user_email", "place_id", "user_address", "user_photo", "user_username", "user_password") VALUES
	('4','Adarsh','7894561237','adarsh@gmail.com','7','Nelcos, Jn., Pala Road, Thodupuzha, Kerala','User_1407.png','adarsh','adarsh');
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_contact", "user_email", "place_id", "user_address", "user_photo", "user_username", "user_password") VALUES
	('5','abhi','8965741236','abhi@gmail.com','7','ERNAKULAM','User_1853.png','abhi123','abhi123');
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_contact", "user_email", "place_id", "user_address", "user_photo", "user_username", "user_password") VALUES
	('6','mercy','7025986475','mercy@gmail.com','7','muvattupuzha','User_1510.png','mercy@gmail.com','mercy123');
REPLACE INTO "tbl_user" ("user_id", "user_name", "user_contact", "user_email", "place_id", "user_address", "user_photo", "user_username", "user_password") VALUES
	('7','achu','9745308563','achus@gmail.com','7','muvattupuzha','User_1865.png','achus123','achus123');
/*!40000 ALTER TABLE "tbl_user" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_wbresult'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_wbresult" (
  "wbresult_id" int(10) unsigned NOT NULL auto_increment,
  "wb_oldphoto" varchar(50) NOT NULL,
  "wb_newphoto" varchar(50) NOT NULL,
  "wb_feedback" varchar(50) NOT NULL,
  "wb_id" tinyint(3) unsigned NOT NULL,
  PRIMARY KEY  ("wbresult_id")
);



#
# Dumping data for table 'tbl_wbresult'
#

# No data found.



#
# Table structure for table 'tbl_workassign'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_workassign" (
  "wa_id" int(10) unsigned NOT NULL auto_increment,
  "wb_id" int(10) unsigned default NULL,
  "employye_id" int(10) unsigned default NULL,
  "assign_date" date default NULL,
  PRIMARY KEY  ("wa_id"),
  UNIQUE KEY "wa_id" ("wa_id")
) AUTO_INCREMENT=2;



#
# Dumping data for table 'tbl_workassign'
#

LOCK TABLES "tbl_workassign" WRITE;
/*!40000 ALTER TABLE "tbl_workassign" DISABLE KEYS;*/
REPLACE INTO "tbl_workassign" ("wa_id", "wb_id", "employye_id", "assign_date") VALUES
	('1','5','8','2022-05-02');
/*!40000 ALTER TABLE "tbl_workassign" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_workbooking'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_workbooking" (
  "wb_id" int(10) unsigned NOT NULL auto_increment,
  "user_id" int(10) unsigned NOT NULL,
  "works_id" int(10) unsigned NOT NULL,
  "wb_date" date NOT NULL,
  "wb_totalamount" int(10) unsigned default NULL,
  "wb_status" int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  ("wb_id")
) AUTO_INCREMENT=102;



#
# Dumping data for table 'tbl_workbooking'
#

LOCK TABLES "tbl_workbooking" WRITE;
/*!40000 ALTER TABLE "tbl_workbooking" DISABLE KEYS;*/
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('1','1','6','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('2','1','6','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('3','1','6','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('4','1','6','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('5','1','3','2022-03-04',NULL,'1');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('6','1','6','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('7','1','6','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('8','1','4','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('9','1','6','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('10','1','5','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('11','1','2','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('12','1','5','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('13','1','5','2022-03-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('14','1','6','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('15','1','3','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('16','1','6','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('17','1','5','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('18','1','6','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('19','1','3','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('20','1','6','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('21','1','4','2022-03-13',NULL,'1');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('22','1','6','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('23','1','5','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('24','1','2','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('25','1','5','2022-03-13',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('26','1','6','2022-03-13',NULL,'2');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('27','1','6','2022-03-14',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('28','1','3','2022-03-14',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('29','1','6','2022-03-14',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('30','1','6','2022-03-16',NULL,'1');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('31','1','3','2022-03-16',NULL,'1');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('32','1','6','2022-03-16',NULL,'2');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('33','1','6','2022-03-18',NULL,'2');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('34','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('35','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('36','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('37','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('38','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('39','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('40','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('41','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('42','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('43','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('44','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('45','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('46','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('47','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('48','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('49','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('50','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('51','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('52','1','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('53','2','7','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('54','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('55','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('56','1','6','2022-03-18',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('57','5','6','2022-04-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('58','5','3','2022-04-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('59','5','6','2022-04-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('60','5','6','2022-04-04',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('61','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('62','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('63','1','8','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('64','1','8','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('65','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('66','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('67','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('68','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('69','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('70','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('71','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('72','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('73','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('74','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('75','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('76','1','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('77','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('78','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('79','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('80','5','8','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('81','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('82','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('83','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('84','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('85','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('86','5','6','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('87','5','3','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('88','5','6','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('89','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('90','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('91','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('92','5','7','2022-04-23',NULL,'1');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('93','5','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('94','2','7','2022-04-23',NULL,'1');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('95','2','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('96','2','7','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('97','2','6','2022-04-23',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('98','1','4','2022-05-02',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('99','1','3','2022-05-11',NULL,'1');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('100','1','3','2022-05-12',NULL,'0');
REPLACE INTO "tbl_workbooking" ("wb_id", "user_id", "works_id", "wb_date", "wb_totalamount", "wb_status") VALUES
	('101','7','16','2022-05-12',NULL,'0');
/*!40000 ALTER TABLE "tbl_workbooking" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_workcategory'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_workcategory" (
  "workcat_id" int(10) unsigned NOT NULL auto_increment,
  "workcat_name" varchar(50) NOT NULL,
  PRIMARY KEY  ("workcat_id")
) AUTO_INCREMENT=16;



#
# Dumping data for table 'tbl_workcategory'
#

LOCK TABLES "tbl_workcategory" WRITE;
/*!40000 ALTER TABLE "tbl_workcategory" DISABLE KEYS;*/
REPLACE INTO "tbl_workcategory" ("workcat_id", "workcat_name") VALUES
	('5','Hair');
REPLACE INTO "tbl_workcategory" ("workcat_id", "workcat_name") VALUES
	('6','hair cut');
REPLACE INTO "tbl_workcategory" ("workcat_id", "workcat_name") VALUES
	('13','hair colouring');
REPLACE INTO "tbl_workcategory" ("workcat_id", "workcat_name") VALUES
	('14','facial');
REPLACE INTO "tbl_workcategory" ("workcat_id", "workcat_name") VALUES
	('15','nail extension');
/*!40000 ALTER TABLE "tbl_workcategory" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_workgallery'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_workgallery" (
  "wg_id" int(10) unsigned NOT NULL auto_increment,
  "works_id" int(10) unsigned NOT NULL,
  "wg_caption" varchar(50) NOT NULL,
  "wg_image" varchar(50) NOT NULL,
  "wg_uploaddate" date NOT NULL,
  PRIMARY KEY  ("wg_id")
) AUTO_INCREMENT=9;



#
# Dumping data for table 'tbl_workgallery'
#

LOCK TABLES "tbl_workgallery" WRITE;
/*!40000 ALTER TABLE "tbl_workgallery" DISABLE KEYS;*/
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('1','1','dwdw','gallery_1400.png','2022-02-18');
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('2','2','fgetgd','gallery_2009.png','2022-02-18');
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('3','3','mmmm','gallery_1460.png','2022-02-24');
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('4','6','QTRR','gallery_1795.png','2022-02-25');
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('5','6','ewedw','gallery_1851.png','2022-02-25');
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('6','6','hello','gallery_1275.png','2022-02-25');
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('7','6','fgefge','gallery_1088.png','2022-02-25');
REPLACE INTO "tbl_workgallery" ("wg_id", "works_id", "wg_caption", "wg_image", "wg_uploaddate") VALUES
	('8','6','mlop','gallery_1627.png','2022-02-25');
/*!40000 ALTER TABLE "tbl_workgallery" ENABLE KEYS;*/
UNLOCK TABLES;


#
# Table structure for table 'tbl_works'
#

CREATE TABLE /*!32312 IF NOT EXISTS*/ "tbl_works" (
  "works_id" int(10) unsigned NOT NULL auto_increment,
  "workcat_id" int(10) unsigned NOT NULL,
  "work_name" varchar(50) NOT NULL,
  "work_rate" int(10) unsigned NOT NULL,
  "work_description" varchar(50) NOT NULL,
  "shop_id" int(10) unsigned NOT NULL,
  "work_image" varchar(50) NOT NULL,
  PRIMARY KEY  ("works_id")
) AUTO_INCREMENT=19;



#
# Dumping data for table 'tbl_works'
#

LOCK TABLES "tbl_works" WRITE;
/*!40000 ALTER TABLE "tbl_works" DISABLE KEYS;*/
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('1','5','abc','1000','asds','5','works_2076.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('2','13','sad','20000','dsa','5','works_1550.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('3','6','abc','6596','dfhgjk','6','works_1001.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('4','6','action','20000','asds','6','works_1090.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('5','5','hair','100','hair','6','works_1495.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('6','5','abc','1000','hair works','7','works_1292.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('7','6','fair & lovely','500','hair cutting','14','works_1742.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('8','14','fail & lovely','1000','facial','14','works_1811.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('9','15','fail & lovely','1500','nail extension','14','works_1045.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('10','6','mist','500','hair cut','13','works_1646.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('11','15','mist','1500','nail extension','13','works_1168.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('12','14','mist','500','facial','13','works_1864.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('13','13','achus','500','hair colouring','12','works_1504.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('14','15','achus','2000','nail extensiom','12','works_1970.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('15','6','achus','100','hair cut','12','works_2049.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('16','13','enara','200','hair cut','11','works_1018.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('17','13','enara','600','hair colouring','11','works_1352.png');
REPLACE INTO "tbl_works" ("works_id", "workcat_id", "work_name", "work_rate", "work_description", "shop_id", "work_image") VALUES
	('18','15','enara','2000','nail extension','11','works_1638.png');
/*!40000 ALTER TABLE "tbl_works" ENABLE KEYS;*/
UNLOCK TABLES;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE;*/
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;*/
